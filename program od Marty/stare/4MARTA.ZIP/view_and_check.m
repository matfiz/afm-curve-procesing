function varargout = view_and_check(varargin)
% VIEW_AND_CHECK M-file for view_and_check.fig
%      VIEW_AND_CHECK, by itself, creates a new VIEW_AND_CHECK or raises the existing
%      singleton*.
%
%      H = VIEW_AND_CHECK returns the handle to a new VIEW_AND_CHECK or the handle to
%      the existing singleton*.
%
%      VIEW_AND_CHECK('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in VIEW_AND_CHECK.M with the given input arguments.
%
%      VIEW_AND_CHECK('Property','Value',...) creates a new VIEW_AND_CHECK or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before view_and_check_OpeningFunction gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to view_and_check_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help view_and_check

% Last Modified by GUIDE v2.5 22-Feb-2004 10:35:41

%-----------------------------------------------------------------
% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @view_and_check_OpeningFcn, ...
                   'gui_OutputFcn',  @view_and_check_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin & isstr(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT

%-----------------------------------------------------------------
% --- Executes just before view_and_check is made visible.
function view_and_check_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to view_and_check (see VARARGIN)

% Choose default command line output for view_and_check
handles.output = hObject;
handles.krzywe = 0;
handles.viewtype=1; % single, all
handles.scaling=1;
handles.viewmode=1; % both, approach, retract
handles.reference=0;
handles.referenceno=1;
handles.save=1;


% Update handles structure

% Next & Prev
h1=findobj(handles.figure1,'Tag','pushbutton1');
h2=findobj(handles.figure1,'Tag','prevbutton');

% Remove
h3=findobj(handles.figure1,'Tag','pushbutton3');

% Plot & Save Menu
h4=findobj(handles.figure1,'Tag','Plot_menu');
h5=findobj(handles.figure1,'Tag','Save_curves_Menu');

% Scaling: Const & Float
h6=findobj(handles.figure1,'Tag','radiobutton1');
h7=findobj(handles.figure1,'Tag','radiobutton2');

% Go to curve
h8=findobj(handles.figure1,'Tag','edit1');


% View mode: both, approach, retract
h9=findobj(handles.figure1,'Tag','radiobutton3');
h10=findobj(handles.figure1,'Tag','radiobutton4');
h11=findobj(handles.figure1,'Tag','radiobutton5');


% Add % Calc menu
h12=findobj(handles.figure1,'Tag','Add_curves_menu');
h13=findobj(handles.figure1,'Tag','Calc_menu');

%Reference

h14=findobj(handles.figure1,'Tag','radiobutton6');
h15=findobj(handles.figure1,'Tag','edit2');


% minimum value hist show & ver

h16=findobj(handles.figure1,'Tag','MVHver_menu');
h17=findobj(handles.figure1,'Tag','SMVH_menu');

set(h1','Enable','Off');
set(h2','Enable','Off');
set(h3','Enable','Off');
set(h4','Enable','Off');
set(h5','Enable','Off');
set(h6','Enable','Off');
set(h7','Enable','Off');
set(h8','Enable','Off');
set(h9','Enable','Off');
set(h10','Enable','Off');
set(h11','Enable','Off');
set(h12','Enable','Off');
set(h13','Enable','Off');
set(h14','Enable','Off');
set(h15','Enable','Off');
set(h16,'Enable','Off');
set(h17','Enable','Off');


guidata(hObject, handles);

% UIWAIT makes view_and_check wait for user response (see UIRESUME)
uiwait(handles.figure1);

%-----------------------------------------------------------------
% --- Outputs from this function are returned to the command line.
function varargout = view_and_check_OutputFcn(hObject, eventdata, handles)
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
%varargout{1} = handles.output;
%varargout{2} = handles.krzywe;


%-----------------------------------------------------------------
% --- Executes on button press in (NEXT).
function pushbutton1_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

krzywe=handles.krzywe;
if (handles.currkrzywa<krzywe.n)
    handles.currkrzywa=handles.currkrzywa+1;
    plotkrzywa(hObject,handles);
    guidata(hObject, handles);
end

%-----------------------------------------------------------------
% --- Executes on button press in prevbutton. (PREV)
function prevbutton_Callback(hObject, eventdata, handles)
% hObject    handle to prevbutton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

krzywe=handles.krzywe;
if (handles.currkrzywa>1)
    handles.currkrzywa=handles.currkrzywa-1;
    plotkrzywa(hObject,handles);
    guidata(hObject, handles);
end

%-----------------------------------------------------------------
function edit1_Callback(hObject, eventdata, handles) % (GOTO curve)
% hObject    handle to edit1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit1 as text
%        str2double(get(hObject,'String')) returns contents of edit1 as a double

krzywe=handles.krzywe;
itemp=str2double(get(hObject,'String'));

if (itemp<=krzywe.n) && (itemp>=1)
     i=itemp;    
     handles.currkrzywa=i;
     guidata(hObject, handles);
     plotkrzywa(hObject,handles);
     set(hObject,'String','');
end


%-----------------------------------------------------------------

% --- Executes on slider movement.
function slider1_Callback(hObject, eventdata, handles)
% hObject    handle to slider1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider

krzywe=handles.krzywe;
val=get(hObject,'Value');
vmax=get(hObject,'Max');
vmin=get(hObject,'Min');


i=round((krzywe.n-1)/(vmax-vmin)*val);
if (i<1) i=1; end
if (i>krzywe.n) i=krzywe.n; end
    

handles.currkrzywa=i;
guidata(hObject, handles);
plotkrzywa(hObject,handles);
set(hObject,'String','');


%-----------------------------------------------------------------

% --- Executes on button press in pushbutton3. (REMOVE)
function pushbutton3_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

button = questdlg('Remove this curve?','Attention!','Yes','No','No');
if strcmp(button,'No')
    return
end

krzywe=handles.krzywe;
if (krzywe.n>1) 
    lista=1:krzywe.n;
    maska=lista~=handles.currkrzywa;
    gdzie=find(maska);
    t_do(:,:)=krzywe.t_do(gdzie,:);
    z_do(:,:)=krzywe.z_do(gdzie,:);
    F_do(:,:)=krzywe.F_do(gdzie,:);
    t_od(:,:)=krzywe.t_od(gdzie,:);
    z_od(:,:)=krzywe.z_od(gdzie,:);
    F_od(:,:)=krzywe.F_od(gdzie,:);
    for i=1:length(gdzie)
        fname{i}=krzywe.fname{gdzie(i)};
    end
    krzywe.t_do=t_do;
    krzywe.z_do=z_do;
    krzywe.F_do=F_do;
    krzywe.t_od=t_od;
    krzywe.z_od=z_od;
    krzywe.F_od=F_od;
    krzywe.n=krzywe.n-1;
    krzywe.fname=fname;
    handles.krzywe=krzywe;
    if handles.currkrzywa>1
        handles.currkrzywa=handles.currkrzywa-1;
    end
    handles.save=0;
    markunsave(handles);
    
    h1=findobj(handles.figure1,'Tag','MVHver_menu');
    h2=findobj(handles.figure1,'Tag','SMVH_menu');
    set(h1,'Enable','Off');
    set(h2,'Enable','Off');
    krzywe.mvh=0;
    
    guidata(hObject, handles);
    plotkrzywa(hObject,handles);
end

% --------------------------------------------------------------------
function File_Menu_Callback(hObject, eventdata, handles)
% hObject    handle to File_Menu (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --------------------------------------------------------------------
function Import_curves_menu_Callback(hObject, eventdata, handles)
% hObject    handle to Import_curves_menu (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

if  ~handles.save
    button = questdlg('Save it?','File not saved','Yes','No','Cancel','Yes');
    if strcmp(button,'Yes')
        [filename, pathname,filterindex] = uiputfile('*.mat', 'Save curves to MAT file');
        krzywe=handles.krzywe;
        save([pathname filename],'krzywe');
        handles.save=1;
    end        
    if strcmp(button,'Cancel')
         return;
    end
end

krzywe=readkurwy(handles);
if (isstruct(krzywe)) 
    krzywe.mvh=0;
    handles.krzywe=krzywe;
    handles.currkrzywa=1;
    plotkrzywa(hObject,handles);
    h1=findobj(handles.figure1,'Tag','pushbutton1');
    h2=findobj(handles.figure1,'Tag','prevbutton');
    h3=findobj(handles.figure1,'Tag','pushbutton3');
    h4=findobj(handles.figure1,'Tag','Plot_menu');
    h5=findobj(handles.figure1,'Tag','Save_curves_Menu');
    h6=findobj(handles.figure1,'Tag','radiobutton1');
    h7=findobj(handles.figure1,'Tag','radiobutton2');
    h8=findobj(handles.figure1,'Tag','edit1');
    h9=findobj(handles.figure1,'Tag','radiobutton3');
    h10=findobj(handles.figure1,'Tag','radiobutton4');
    h11=findobj(handles.figure1,'Tag','radiobutton5');
    h12=findobj(handles.figure1,'Tag','Add_curves_menu');
    h13=findobj(handles.figure1,'Tag','Calc_menu');
    h14=findobj(handles.figure1,'Tag','radiobutton6');
    h15=findobj(handles.figure1,'Tag','edit2');

    set(h1','Enable','On');
    set(h2','Enable','On');
    set(h3','Enable','On');
    set(h4','Enable','On');
    set(h5','Enable','On');
    set(h6','Enable','On');
    set(h7','Enable','On');
    set(h8','Enable','On');
    set(h9','Enable','On');
    set(h10','Enable','On');
    set(h11','Enable','On');
    set(h12','Enable','On');
    set(h13','Enable','On');
    set(h14,'Enable','On');
    set(h15,'Enable','On');

    h16=findobj(handles.figure1,'Tag','text9');
    set(h16,'String','Source: Import');

    h17=findobj(handles.figure1,'Tag','MVHver_menu');
    h18=findobj(handles.figure1,'Tag','SMVH_menu');
    set(h17,'Enable','Off');
    set(h18,'Enable','Off');

    handles.viewtype=1; % SINGLE
    handles.save=0;
    markunsave(handles);
    guidata(hObject, handles);
end
% --------------------------------------------------------------------
function Load_curves_Callback(hObject, eventdata, handles)
% hObject    handle to Untitled_1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)



if  ~handles.save
    button = questdlg('Save it?','File not saved','Yes','No','Cancel','Yes');
    if strcmp(button,'Yes')
        [filename, pathname,filterindex] = uiputfile('*.mat', 'Save curves to MAT file');
        krzywe=handles.krzywe;
        save([pathname filename],'krzywe');
        handles.save=1;    
    end   
    if strcmp(button,'Cancel')
         return;
    end
end


[filename, pathname,filterindex] = uigetfile('*.mat', 'Load curves from MAT file');
if (filename)
    s=load([pathname filename]);
    handles.krzywe=s.krzywe;
    if (~isfield(handles.krzywe,'mvh'))
        handles.krzywe.mvh=0;
    end
    handles.currkrzywa=1;
    plotkrzywa(hObject,handles);
    h1=findobj(handles.figure1,'Tag','pushbutton1');
    h2=findobj(handles.figure1,'Tag','prevbutton');
    h3=findobj(handles.figure1,'Tag','pushbutton3');
    h4=findobj(handles.figure1,'Tag','Plot_menu');
    h5=findobj(handles.figure1,'Tag','Save_curves_Menu');
    h6=findobj(handles.figure1,'Tag','radiobutton1');
    h7=findobj(handles.figure1,'Tag','radiobutton2');
    h8=findobj(handles.figure1,'Tag','edit1');

    h9=findobj(handles.figure1,'Tag','radiobutton3');
    h10=findobj(handles.figure1,'Tag','radiobutton4');
    h11=findobj(handles.figure1,'Tag','radiobutton5');
    h12=findobj(handles.figure1,'Tag','Add_curves_menu');
    h13=findobj(handles.figure1,'Tag','Calc_menu');
    h14=findobj(handles.figure1,'Tag','radiobutton6');
    h15=findobj(handles.figure1,'Tag','edit2');

    set(h1','Enable','On');
    set(h2','Enable','On');
    set(h3','Enable','On');
    set(h4','Enable','On');
    set(h5','Enable','On');
    set(h6','Enable','On');
    set(h7','Enable','On');
    set(h8','Enable','On');
    set(h9','Enable','On');
    set(h10','Enable','On');
    set(h11','Enable','On');
    set(h12','Enable','On');
    set(h13','Enable','On');
    set(h14,'Enable','On');
    set(h15,'Enable','On');

    h16=findobj(handles.figure1,'Tag','text9');
    set(h16,'String',['Source:' pathname filename]);

    h17=findobj(handles.figure1,'Tag','MVHver_menu');
    h18=findobj(handles.figure1,'Tag','SMVH_menu');
    if (handles.krzywe.mvh)
        set(h17,'Enable','On');
        set(h18,'Enable','On');
    else 
        set(h17,'Enable','Off');
        set(h18,'Enable','Off');
    end

    handles.viewtype=1; % SINGLE
    handles.save=1;
    guidata(hObject, handles);

end
% --------------------------------------------------------------------
function Save_curves_Menu_Callback(hObject, eventdata, handles)
% hObject    handle to Save_curves_Menu (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


[filename, pathname,filterindex] = uiputfile('*.mat', 'Save curves to MAT file');
if (filename)
    krzywe=handles.krzywe;
    save([pathname filename],'krzywe');
    h1=findobj(handles.figure1,'Tag','text9');
    set(h1,'String',['Source: ' pathname filename]);
    handles.save=1;
    marksave(handles);
end

%-------------------------------------------------------------------
function generalplot(hObject,handles)
    if (handles.viewtype==1)
        plotkrzywa(hObject,handles);
    end
    if (handles.viewtype==2)
        plotkrzyweapproach(hObject,handles);
    end
    if (handles.viewtype==3)
        plotkrzyweretract(hObject,handles);
    end


%-------------------------------------------------------------------
function plotkrzyweapproach(hObject,handles)

axprev=gca;
ax1=findobj(handles.figure1,'Tag','axes1');
axes(ax1);


krzywe=handles.krzywe;
plot(krzywe.z_do(1,:),krzywe.F_do*1e9);
h = findobj(handles.figure1, 'Tag', 'filenametext');
set(h,'String','Approach');
h = findobj(handles.figure1, 'Tag', 'nummertext');
set(h,'String',['Curve No. ' '- all']);
xlabel('z [\mu m]');
ylabel('F [nN]');
grid on
guidata(hObject, handles);
set(gca,'Tag','axes1');
axes(axprev);

%-------------------------------------------------------------------
function plotkrzyweretract(hObject,handles)

axprev=gca;
ax1=findobj(handles.figure1,'Tag','axes1');
axes(ax1);

krzywe=handles.krzywe;
plot(krzywe.z_od(1,:),krzywe.F_od*1e9);
h = findobj(handles.figure1, 'Tag', 'filenametext');
set(h,'String','Retract');
h = findobj(handles.figure1, 'Tag', 'nummertext');
set(h,'String',['Curve No. ' '- all']);
xlabel('z [\mu m]');
ylabel('F [nN]');
grid on
guidata(hObject, handles);
set(gca,'Tag','axes1');
axes(axprev);

%-----------------------------------------------------------------

% --- Executes during object creation, after setting all properties.
function figure1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to figure1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called


%-----------------------------------------------------------------


% --- Executes when user attempts to close figure1.
function figure1_CloseRequestFcn(hObject, eventdata, handles)
% hObject    handle to figure1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: delete(hObject) closes the figure
if handles.save
    button = questdlg('Are you sure to EXIT','Exiting','Yes','No','No')
    if strcmp(button,'Yes')
        uiresume(handles.figure1);
        delete(hObject);
    end
else
    button = questdlg('Save it?','File not saved','Yes','No','Cancel','Yes');
    if strcmp(button,'Yes')
        [filename, pathname,filterindex] = uiputfile('*.mat', 'Save curves to MAT file');
        krzywe=handles.krzywe;
        save([pathname filename],'krzywe');
    end
   if strcmp(button,'No')  
        uiresume(handles.figure1);
        delete(hObject);
    end
    
    
end

%-----------------------------------------------------------------

% --- Executes during object deletion, before destroying properties.
function figure1_DeleteFcn(hObject, eventdata, handles)
% hObject    handle to figure1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
uiresume(handles.figure1);


% --------------------------------------------------------------------
function Plot_menu_Callback(hObject, eventdata, handles)
% hObject    handle to Plot_menu (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --------------------------------------------------------------------
function View_single_menu_Callback(hObject, eventdata, handles)
% hObject    handle to View_single_menu (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
handles.viewtype=1; % SINGLE
h1=findobj(handles.figure1,'Tag','pushbutton1');
h2=findobj(handles.figure1,'Tag','prevbutton');
h3=findobj(handles.figure1,'Tag','pushbutton3');
h6=findobj(handles.figure1,'Tag','radiobutton1');
h7=findobj(handles.figure1,'Tag','radiobutton2');
h8=findobj(handles.figure1,'Tag','edit1');
h9=findobj(handles.figure1,'Tag','radiobutton6');
h10=findobj(handles.figure1,'Tag','edit2');


set(h1','Enable','On');
set(h2','Enable','On');
set(h3','Enable','On');
set(h6','Enable','On');
set(h7','Enable','On');
set(h8','Enable','On');
set(h9,'Enable','On');
set(h10,'Enable','On');


plotkrzywa(hObject,handles);
guidata(hObject, handles);


% --------------------------------------------------------------------
function View_approach_all_menu_Callback(hObject, eventdata, handles)
% hObject    handle to View_approach_all_menu (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

handles.viewtype=2; % SINGLE
h1=findobj(handles.figure1,'Tag','pushbutton1');
h2=findobj(handles.figure1,'Tag','prevbutton');
h3=findobj(handles.figure1,'Tag','pushbutton3');
h8=findobj(handles.figure1,'Tag','edit1');
h9=findobj(handles.figure1,'Tag','radiobutton6');
h10=findobj(handles.figure1,'Tag','edit2');


set(h1','Enable','Off');
set(h2','Enable','Off');
set(h3','Enable','Off');
set(h8','Enable','Off');
set(h9,'Enable','Off');
set(h10,'Enable','Off');

h6=findobj(handles.figure1,'Tag','radiobutton1');
h7=findobj(handles.figure1,'Tag','radiobutton2');
set(h6','Enable','Off');
set(h7','Enable','Off');

plotkrzyweapproach(hObject,handles);
guidata(hObject, handles);

% --------------------------------------------------------------------
function View_retract_all_menu_Callback(hObject, eventdata, handles)
% hObject    handle to View_retract_all_menu (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


handles.viewtype=3; % SINGLE
h1=findobj(handles.figure1,'Tag','pushbutton1');
h2=findobj(handles.figure1,'Tag','prevbutton');
h3=findobj(handles.figure1,'Tag','pushbutton3');
h6=findobj(handles.figure1,'Tag','radiobutton1');
h7=findobj(handles.figure1,'Tag','radiobutton2');
h8=findobj(handles.figure1,'Tag','edit1');
h9=findobj(handles.figure1,'Tag','radiobutton6');
h10=findobj(handles.figure1,'Tag','edit2');


set(h1','Enable','Off');
set(h2','Enable','Off');
set(h3','Enable','Off');

set(h6','Enable','Off');
set(h7','Enable','Off');
set(h7','Enable','Off');

set(h9,'Enable','On');
set(h10,'Enable','Off');

plotkrzyweretract(hObject,handles);
guidata(hObject, handles);

%-----------------------------------------------------------------

% --- Executes on button press in zoombutton.
function zoombutton_Callback(hObject, eventdata, handles)
% hObject    handle to zoombutton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

zoom;

%-----------------------------------------------------------------

% --- Executes on button press in radiobutton1. (SCALING - Const)
function radiobutton1_Callback(hObject, eventdata, handles)
% hObject    handle to radiobutton1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of radiobutton1
handles.scaling=1;
h1=findobj(handles.figure1,'Tag','radiobutton1');
h2=findobj(handles.figure1,'Tag','radiobutton2');
set(h1,'Value',1);
set(h2,'Value',0);
guidata(hObject, handles);

if (handles.viewtype==1)
    plotkrzywa(hObject,handles);
end

%-----------------------------------------------------------------

% --- Executes on button press in radiobutton2. (SCALING - float)
function radiobutton2_Callback(hObject, eventdata, handles)
% hObject    handle to radiobutton2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of radiobutton2

handles.scaling=0;
h1=findobj(handles.figure1,'Tag','radiobutton1');
h2=findobj(handles.figure1,'Tag','radiobutton2');
set(h1,'Value',0);
set(h2,'Value',1);
guidata(hObject, handles);
if (handles.viewtype==1)
    plotkrzywa(hObject,handles);
end

%-----------------------------------------------------------------

% --- Executes during object creation, after setting all properties.
function edit1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc
    set(hObject,'BackgroundColor','white');
else
    set(hObject,'BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
end

%-----------------------------------------------------------------

% --- Executes on button press in radiobutton3.
function radiobutton3_Callback(hObject, eventdata, handles)
% hObject    handle to radiobutton3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of radiobutton3
handles.viewmode=1;
h3=findobj(handles.figure1,'Tag','radiobutton3');
h4=findobj(handles.figure1,'Tag','radiobutton4');
h5=findobj(handles.figure1,'Tag','radiobutton5');

set(h3,'Value',1);
set(h4,'Value',0);
set(h5,'Value',0);

guidata(hObject, handles);

if (handles.viewtype==1)
    plotkrzywa(hObject,handles);
end

%-----------------------------------------------------------------

% --- Executes on button press in radiobutton4.
function radiobutton4_Callback(hObject, eventdata, handles)
% hObject    handle to radiobutton4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of radiobutton4
handles.viewmode=2;
h3=findobj(handles.figure1,'Tag','radiobutton3');
h4=findobj(handles.figure1,'Tag','radiobutton4');
h5=findobj(handles.figure1,'Tag','radiobutton5');

set(h3,'Value',0);
set(h4,'Value',1);
set(h5,'Value',0);

guidata(hObject, handles);

if (handles.viewtype==1)
    plotkrzywa(hObject,handles);
end

%-----------------------------------------------------------------

% --- Executes on button press in radiobutton5.
function radiobutton5_Callback(hObject, eventdata, handles)
% hObject    handle to radiobutton5 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of radiobutton5

handles.viewmode=3;
h3=findobj(handles.figure1,'Tag','radiobutton3');
h4=findobj(handles.figure1,'Tag','radiobutton4');
h5=findobj(handles.figure1,'Tag','radiobutton5');

set(h3,'Value',0);
set(h4,'Value',0);
set(h5,'Value',1);

guidata(hObject, handles);

if (handles.viewtype==1)
    plotkrzywa(hObject,handles);
end

%-----------------------------------------------------------------


% --- Executes on button press in radiobutton6.
function radiobutton6_Callback(hObject, eventdata, handles)
% hObject    handle to radiobutton6 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of radiobutton6

if handles.reference==1
    handles.reference=0;
     plotkrzywa(hObject,handles);
else
    handles.reference=1;
    handles.referenceno=handles.currkrzywa;
    plotkrzywa(hObject,handles);
    h1=findobj(handles.figure1,'Tag','edit2');
    set(h1,'String',num2str(handles.referenceno));
end

guidata(hObject, handles);




% --- Executes during object creation, after setting all properties.
function edit2_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc
    set(hObject,'BackgroundColor','white');
else
    set(hObject,'BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
end


%--------------------------------------------------------------------------
function edit2_Callback(hObject, eventdata, handles)
% hObject    handle to edit2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit2 as text
%        str2double(get(hObject,'String')) returns contents of edit2 as a double

krzywe=handles.krzywe;
itemp=str2double(get(hObject,'String'));
if (itemp>0) && (itemp<=krzywe.n)
    i=itemp;
    handles.referenceno=i;
end
guidata(hObject, handles);
plotkrzywa(hObject,handles);


% --- Executes on button press in pushbutton5.
function pushbutton5_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton5 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
[x,y]=ginput(2);
        


% --------------------------------------------------------------------
function Add_curves_menu_Callback(hObject, eventdata, handles)
% hObject    handle to Add_curves_menu (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


if  ~handles.save
    button = questdlg('Save it?','File not saved','Yes','No','Cancel','Yes');
    if strcmp(button,'Yes')
        [filename, pathname,filterindex] = uiputfile('*.mat', 'Save curves to MAT file');
        krzywe=handles.krzywe;
        save([pathname filename],'krzywe');
        marksave(handles);
        handles.save=1;    
    end   
    if strcmp(button,'Cancel')
         return;
    end
end

krzyweold=handles.krzywe;
krzywenew=addkurwy(krzyweold);
handles.krzywe=krzywenew;
guidata(hObject, handles);
plotkrzywa(hObject,handles);
h14=findobj(handles.figure1,'Tag','text9');
set(h14,'String',['Source: Multiple sources']);
handles.save=0;
markunsave(handles);


% --------------------------------------------------------------------
function Calc_Menu_Callback(hObject, eventdata, handles)
% hObject    handle to Calc_Menu (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --------------------------------------------------------------------
function Remove_vertical_offset_Menu_Callback(hObject, eventdata, handles)
% hObject    handle to Remove_vertical_offset_Menu (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

handles.save=0;
markunsave(handles);
krzywe=handles.krzywe;


View_approach_all_menu_Callback(hObject, eventdata, handles)

uiwait(msgbox('Set the minimum linear range (one mouse click)','modal'));
[zlimit,dummy]=ginput(1);
krzywe=remove_vert_offset(krzywe,zlimit);
handles.krzywe=krzywe;
handles.viewtype=2;


h1=findobj(handles.figure1,'Tag','MVHver_menu');
h2=findobj(handles.figure1,'Tag','SMVH_menu');
set(h1,'Enable','Off');
set(h2,'Enable','Off');
krzywe.mvh=0;
    

guidata(hObject, handles);
generalplot(hObject,handles);


% --- Executes during object creation, after setting all properties.
function slider1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to slider1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background, change
%       'usewhitebg' to 0 to use default.  See ISPC and COMPUTER.
usewhitebg = 1;
if usewhitebg
    set(hObject,'BackgroundColor',[.9 .9 .9]);
else
    set(hObject,'BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
end


% --------------------------------------------------------------------
function MVH_menu_Callback(hObject, eventdata, handles)
% hObject    handle to MVH_menu (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
krzywe=handles.krzywe;


%handles.save=0;
%markunsave(handles);
krzywe.mvh=1;

ans=inputdlg('Input number of bins','Histogram',1);
nbins=str2double(ans);
if (~nbins) nbins=10; end
[xhist_min_val,nhist_min_val]=minimum_value_hist(handles,nbins);
krzywe.xhist_min_val=xhist_min_val;
krzywe.nhist_min_val=nhist_min_val;
handles.krzywe=krzywe;
h1=findobj(handles.figure1,'Tag','MVHver_menu');
h2=findobj(handles.figure1,'Tag','SMVH_menu');
set(h1,'Enable','On');
set(h2,'Enable','On');
guidata(hObject, handles);
histofig(xhist_min_val*1e9,nhist_min_val);
bar(xhist_min_val*1e9,nhist_min_val);
xlabel('F[nN]');
ylabel('Frequency');

% --------------------------------------------------------------------
function verhisto_Callback(hObject, eventdata, handles)
% hObject    handle to Untitled_3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


%--------------------------------------%
function markunsave(handles)
h1=findobj(handles.figure1,'Tag','text9');
s=get(h1,'String');
nc=findstr(s,'*');
 
if isempty(nc)
    ss=[s '*'];
    set(h1,'String',ss);
end

function marksave(handles)
h1=findobj(handles.figure1,'Tag','text9');
s=get(h1,'String');
nc=findstr(s,'*');
if nc
    ss=s(1:nc-1);
    set(h1,'String',ss);
end


% --------------------------------------------------------------------
function SMVH_menu_Callback(hObject, eventdata, handles)
% hObject    handle to SMVH_menu (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


krzywe=handles.krzywe;
histofig(krzywe.xhist_min_val*1e9,krzywe.nhist_min_val);
bar(krzywe.xhist_min_val*1e9,krzywe.nhist_min_val);
xlabel('F[nN]');
ylabel('Frequency');
